import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'user-cmp',
    moduleId: module.id,
    templateUrl: 'user.component.html'
})

export class UserComponent implements OnInit{
    ngOnInit(){
        // $.getScript('../../../assets/js/material-dashboard.js');

    }
}
